# Migration interface: asset_balance

> Status: **draft-unverified** · tested release: none (draft, ECC 6.0 on NetWeaver 7.40 SP08 assumed). Nothing below has been run on a system.

- **Read by:** customer-selected supported posting interface; reference data is not posted
- **Load after:** `fixed_asset`
- **Business key:** `CompanyCode`, `MasterFixedAsset`, `FixedAsset`, `FiscalYear`, `DepreciationArea` · numbering **keep**
- **Key rule:** Preserve source identifiers in an audit ledger; map regenerated internal IDs and target numbering. Never assume internal IDs survive migration.

The consumption views deliver the values **exactly as stored in ECC**. Changing values (new plants, new numbers, ...) is up to the load program.

## `ZFAX_C_AssetBalanceMig`

- Source: `ZFAX_I_AssetBalance`
- Keys: `CompanyCode`, `MasterFixedAsset`, `FixedAsset`, `FiscalYear`, `DepreciationArea`
- Scope: `all rows`
- Delivery mode: **balance**
- Before posting: Unscoped candidate rows. Approve the full-key population at cutover; use customer-cohort-project.json. Depreciation areas, currencies, fiscal years and transfer dates must be agreed. ANLC values are fiscal-year accumulations, not a ready-made posting file. Asset balances must not also enter the general ledger opening balance. Asset transaction history is reconciliation reference data; Universal Parallel Accounting requires a separate supported interface assessment.

| Element | Source (ECC) | Target (S/4HANA) | Rule | Compared |
|---|---|---|---|---|
| `CompanyCode` | ANLC-BUKRS | customer interface field: CompanyCode (unconfirmed) | copy | yes |
| `MasterFixedAsset` | ANLC-ANLN1 | customer interface field: MasterFixedAsset (unconfirmed) | copy | yes |
| `FixedAsset` | ANLC-ANLN2 | customer interface field: FixedAsset (unconfirmed) | copy | yes |
| `FiscalYear` | ANLC-GJAHR | customer interface field: FiscalYear (unconfirmed) | copy | yes |
| `DepreciationArea` | ANLC-AFABE | customer interface field: DepreciationArea (unconfirmed) | copy | yes |
| `CumulativeAcquisition` | ANLC-KANSW | customer interface field: CumulativeAcquisition (unconfirmed) | copy | yes |
| `CumulativeDepreciation` | ANLC-KNAFA | customer interface field: CumulativeDepreciation (unconfirmed) | copy | yes |
| `CurrentYearAcquisition` | ANLC-ANSWL | customer interface field: CurrentYearAcquisition (unconfirmed) | copy | yes |
| `PostedDepreciation` | ANLC-NAFAG | customer interface field: PostedDepreciation (unconfirmed) | copy | yes |

## Reconciliation

- Counts: `ZFAX_C_AssetBalanceMigCount` (ECC) vs `-` (S/4HANA) per `CompanyCode`

```bash
python3 tools/mig_reconcile.py counts --product fi_aa_mig_ecc --module asset_balance --source ecc_counts.csv --target s4_counts.csv
```

## Open gaps

- Depreciation areas, currencies, fiscal years and transfer dates must be agreed. ANLC values are fiscal-year accumulations, not a ready-made posting file. Asset balances must not also enter the general ledger opening balance. Asset transaction history is reconciliation reference data; Universal Parallel Accounting requires a separate supported interface assessment.
