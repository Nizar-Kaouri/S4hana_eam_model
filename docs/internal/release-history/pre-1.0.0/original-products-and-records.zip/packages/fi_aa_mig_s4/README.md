# ModuPorter Asset Accounting target companion

Draft target CDS candidates and target CSV adapter contracts. Verify released-view fields and key grain on S/4HANA 2025 before activation.

Run preparation and Python comparison commands from the paired fi_aa_mig_ecc ZIP. This target ZIP provides src objects and customer/target-adapters.json; it does not supply source extraction or a posting interface. Follow ACTIVATION_ORDER.txt and the source pack CUSTOMER_WORKFLOW.md. All SAP runtime behavior remains unverified.
