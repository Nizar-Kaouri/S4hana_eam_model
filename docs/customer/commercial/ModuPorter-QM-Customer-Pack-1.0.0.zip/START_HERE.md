# ModuPorter QM

Version 1.0.0 | KAOURI INNOVATECH

Read the English or German manual in docs. Import the SOURCE archive into your source system. Follow ACTIVATION_ORDER.txt inside each archive. Open VDM-SOURCE.html in a browser to explore dependencies.

The templates provide read-only source extraction and field mappings. Implement creation of target business objects through your chosen SAP interface. See docs/SOURCE/SUPPORTED_SCOPE.md and docs/SOURCE/LICENSE.md for the exact scope and unlimited-use/modification terms, excluding resale of the template library.
